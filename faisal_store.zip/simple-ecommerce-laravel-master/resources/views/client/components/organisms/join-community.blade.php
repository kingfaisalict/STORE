<div class="bg-primary py-5 text-center container mt-5" style="border-radius:1.5rem;background: linear-gradient(180deg, rgba(37, 57, 111, 0.5) 0%, rgba(37, 57, 111, 0.5) 92.57%);">
    <h1 class="text-white">Join Our Community</h1>
    <p class="text-white fs-5">Meet the company team, collector, announcements, special offers and more . . .</p>
    <x-molecules.button text="Launch Discord" align="center" type="light"/>
</div>