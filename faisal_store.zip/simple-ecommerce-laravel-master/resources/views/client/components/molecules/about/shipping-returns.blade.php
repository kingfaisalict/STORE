<div class="shipping py-md-5 py-2" id="shippingandreturns">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <h3 class="font-primary"><u>Shipping & Returns</u></h3>
      </div>
      <div class="col-lg-8 col-md-8 col-12">
        <p class="font-secondary">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias pariatur voluptates, a dicta dolore repudiandae eos provident hic error? Non accusamus consequatur odio iste saepe, natus eligendi totam incidunt voluptate?</p>
        <p class="font-secondary">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias pariatur voluptates, a dicta dolore repudiandae eos provident hic error? Non accusamus consequatur odio iste saepe, natus eligendi totam incidunt voluptate?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sunt atque at repudiandae iusto! Laboriosam iusto animi ipsum, corrupti, exercitationem fugiat consectetur perferendis rem enim ad non est eos! Labore, qui?</p>
      </div>
    </div>
  </div>
</div>