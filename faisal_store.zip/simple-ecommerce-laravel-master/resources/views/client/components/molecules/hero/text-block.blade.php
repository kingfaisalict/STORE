@push('css')
    <link rel="stylesheet" href="{{ asset('client/components/molecules/hero/text-block.css') }}">
@endpush

<div class="text-center text-block-hero py-5">
    <h1>Sustainable yet stylish lifestye</h1>
    <p>Autem eveniet eum delectus pariatur. Et maiores sit sed placeat quas voluptatum qui. Suscipit veritatis est provident illum commodi. Voluptas quos culpa. Nobis ex nihil laudantium.</p>
</div>